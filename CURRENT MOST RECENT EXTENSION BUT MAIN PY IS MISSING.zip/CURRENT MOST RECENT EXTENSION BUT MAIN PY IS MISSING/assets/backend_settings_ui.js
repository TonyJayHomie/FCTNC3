(async () => {
  const container = document.getElementById("__cfc_settings_container");
  if (!container) return;

  container.innerHTML = `
    <div style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
                background:#1a1a2e;color:#e0e0e0;padding:40px;display:flex;
                justify-content:center;margin:0;min-height:100vh">
      <div style="max-width:600px;width:100%">
        <h1 style="font-size:28px;margin-bottom:8px;color:#fff">Backend Settings</h1>
        <p style="color:#888;margin-bottom:30px">Configure your custom backend / proxy endpoint</p>
        <div id="bs_status" style="padding:12px;border-radius:8px;margin-bottom:20px;
             display:none;font-size:14px"></div>
        <label style="display:block;margin-bottom:6px;font-weight:600;color:#ccc">Backend URL</label>
        <input type="text" id="bs_backendUrl"
          style="width:100%;padding:12px;border:1px solid #333;border-radius:8px;
                 background:#16213e;color:#fff;font-size:14px;margin-bottom:20px;
                 font-family:monospace;box-sizing:border-box">
        <label style="display:block;margin-bottom:6px;font-weight:600;color:#ccc">
          Model Aliases (JSON, optional)</label>
        <textarea id="bs_modelAliases"
          style="width:100%;padding:12px;border:1px solid #333;border-radius:8px;
                 background:#16213e;color:#fff;font-size:14px;margin-bottom:20px;
                 font-family:monospace;box-sizing:border-box;min-height:100px;
                 resize:vertical"></textarea>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:20px">
          <input type="checkbox" id="bs_blockAnalytics" checked style="width:auto;margin:0">
          <label style="margin:0;font-weight:600;color:#ccc">Block analytics / telemetry</label>
        </div>
        <button id="bs_saveBtn"
          style="padding:12px 24px;border:none;border-radius:8px;font-size:14px;
                 font-weight:600;cursor:pointer;margin-right:10px;
                 background:#e07a5f;color:#fff">Save Settings</button>
        <button id="bs_testBtn"
          style="padding:12px 24px;border:none;border-radius:8px;font-size:14px;
                 font-weight:600;cursor:pointer;background:#333;color:#fff">Test Connection</button>
        <div style="margin-top:30px;padding:20px;border-radius:8px;
                    background:#16213e;border:1px solid #333">
          <p><strong style="color:#e07a5f">How it works:</strong> All Claude API calls redirect
             to your backend URL. No login. No external domains. Everything stays local.</p>
          <p><strong>LM Studio:</strong>
             <code style="background:#0d1117;padding:3px 8px;border-radius:4px;
                          font-family:monospace;color:#7ee8fa">http://127.0.0.1:1234/v1</code></p>
          <p><strong>Ollama:</strong>
             <code style="background:#0d1117;padding:3px 8px;border-radius:4px;
                          font-family:monospace;color:#7ee8fa">http://127.0.0.1:11434</code></p>
          <p><strong>Custom proxy:</strong> your proxy address</p>
        </div>
      </div>
    </div>`;

  const $ = id => document.getElementById(id);

  function showStatus(msg, isError) {
    const el = $("bs_status");
    el.textContent = msg;
    el.style.display = "block";
    el.style.background = isError ? "#3d0000" : "#1b4332";
    el.style.color      = isError ? "#ff6b6b" : "#95d5b2";
  }

  // Direct chrome.storage.local — runs inside extension context (chrome-extension://)
  const { hijackSettings } = await chrome.storage.local.get("hijackSettings");
  const s = {
    backendUrl:    "http://127.0.0.1:1234/v1",
    modelAliases:  {},
    blockAnalytics: true,
    ...(hijackSettings || {}),
  };
  $("bs_backendUrl").value    = s.backendUrl;
  $("bs_modelAliases").value  = Object.keys(s.modelAliases).length
    ? JSON.stringify(s.modelAliases, null, 2) : "";
  $("bs_blockAnalytics").checked = s.blockAnalytics;

  $("bs_saveBtn").onclick = async () => {
    let modelAliases = {};
    const raw = $("bs_modelAliases").value.trim();
    if (raw) {
      try { modelAliases = JSON.parse(raw); }
      catch { showStatus("Invalid JSON in model aliases", true); return; }
    }
    const settings = {
      backendUrl:    $("bs_backendUrl").value.trim() || "http://127.0.0.1:1234/v1",
      modelAliases,
      blockAnalytics: $("bs_blockAnalytics").checked,
    };
    await chrome.storage.local.set({ hijackSettings: settings });
    try { localStorage.setItem("apiBaseUrl", settings.backendUrl); } catch(e) {}
    showStatus("Saved! Backend: " + settings.backendUrl);
  };

  $("bs_testBtn").onclick = async () => {
    const url = $("bs_backendUrl").value.trim() || "http://127.0.0.1:1234/v1";
    try {
      const base = url.replace(/\/v1\/?$/, "");
      const resp = await fetch(base + "/v1/models");
      if (resp.ok) {
        const data = await resp.json();
        const models = data.data?.map(m => m.id).join(", ") || "OK";
        showStatus("Connected! Models: " + models);
      } else {
        showStatus("HTTP " + resp.status, true);
      }
    } catch(e) {
      showStatus("Cannot reach " + url + " \u2014 is your backend running?", true);
    }
  };
})();
