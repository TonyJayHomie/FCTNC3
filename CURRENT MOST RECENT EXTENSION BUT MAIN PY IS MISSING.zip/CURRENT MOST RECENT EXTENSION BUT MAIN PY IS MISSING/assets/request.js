// request.js — local CFC hijack.
// Replaces cocodem's 111724.xyz/8787 version with local proxy on port 8520.
// Architecture matches cocodem exactly. No phone home.

const cfcBase = "http://localhost:8520/"

export function isMatch(u, includes) {
  if (typeof u == "string") {
    u = new URL(u, location?.origin)
  }
  return includes.some((v) => {
    if (u.host == v) return !0
    if (u.href.startsWith(v)) return !0
    if (u.pathname.startsWith(v)) return !0
    if (v[0] == "*" && (u.host + u.pathname).indexOf(v.slice(1)) != -1)
      return !0
    return !1
  })
}

async function clearApiKeyLogin() {
  const { accessToken } = await chrome.storage.local.get({ accessToken: "" })
  const payload = JSON.parse(
    (accessToken && atob(accessToken.split(".")[1] || "")) || "{}"
  )
  if (payload && payload.iss == "auth") {
    await chrome.storage.local.set({
      accessToken: "",
      refreshToken: "",
      tokenExpiry: 0,
    })
    await getOptions(!0)
  }
}

if (!globalThis.__cfc_options) {
  globalThis.__cfc_options = {
    mode: "",
    cfcBase: cfcBase,
    anthropicBaseUrl: "",
    apiBaseIncludes: ["https://api.anthropic.com/v1/"],
    proxyIncludes: [
      "cdn.segment.com",
      "featureassets.org",
      "assetsconfigcdn.org",
      "featuregates.org",
      "api.segment.io",
      "prodregistryv2.org",
      "beyondwickedmapping.org",
      "api.honeycomb.io",
      "statsigapi.net",
      "events.statsigapi.net",
      "api.statsigcdn.com",
      "*ingest.us.sentry.io",
      "https://api.anthropic.com/api/oauth/profile",
      "https://api.anthropic.com/api/bootstrap",
      "https://console.anthropic.com/v1/oauth/token",
      "https://platform.claude.com/v1/oauth/token",
      "https://api.anthropic.com/api/oauth/account",
      "https://api.anthropic.com/api/oauth/organizations",
      "https://api.anthropic.com/api/oauth/chat_conversations",
      "/api/web/domain_info/browser_extension",
      "/api/web/url_hash_check/browser_extension",
    ],
    discardIncludes: [
      "cdn.segment.com",
      "api.segment.io",
      "events.statsigapi.net",
      "api.honeycomb.io",
      "prodregistryv2.org",
      "*ingest.us.sentry.io",
      "browser-intake-us5-datadoghq.com",
    ],
    modelAlias: {},
    ui: {},
    uiNodes: [],
  }
}

let _optionsPromise = null
let _updateAt = 0

export async function getOptions(force = false) {
  const fetch = globalThis.__fetch
  const options = globalThis.__cfc_options
  const baseUrl = options.cfcBase || cfcBase

  if (!_optionsPromise && (force || Date.now() - _updateAt > 1000 * 3600)) {
    // EXACT cocodem pattern: setTimeout resolve as hard timeout,
    // finally block calls resolve() (idempotent) and clears the promise.
    _optionsPromise = new Promise(async (resolve) => {
      setTimeout(resolve, 1000 * 2.8)
      try {
        const id = chrome?.runtime?.id || "unknown"
        const manifest = (typeof chrome !== "undefined" && chrome.runtime?.getManifest)
          ? chrome.runtime.getManifest()
          : { version: "0" }
        const url = baseUrl + `api/options?id=${id}&v=${manifest.version}`
        const res = await fetch(url, {
          headers: force ? { "Cache-Control": "no-cache" } : {},
        })
        const {
          mode,
          cfcBase: newCfcBase,
          anthropicBaseUrl,
          apiBaseIncludes,
          proxyIncludes,
          discardIncludes,
          modelAlias,
          ui,
          uiNodes,
        } = await res.json()
        options.mode          = mode
        options.cfcBase       = newCfcBase   || options.cfcBase
        options.anthropicBaseUrl = anthropicBaseUrl || options.anthropicBaseUrl
        options.apiBaseIncludes  = apiBaseIncludes  || options.apiBaseIncludes
        options.proxyIncludes    = proxyIncludes    || options.proxyIncludes
        options.discardIncludes  = discardIncludes  || options.discardIncludes
        options.modelAlias    = modelAlias    || options.modelAlias
        options.ui            = ui            || options.ui
        options.uiNodes       = uiNodes       || options.uiNodes
        _updateAt = Date.now()
        if (mode == "claude") {
          await clearApiKeyLogin()
        }
      } catch (e) {
        // local proxy may not be running yet; safe to swallow
      } finally {
        resolve()
        _optionsPromise = null
      }
    })
  }

  if (_optionsPromise) {
    await _optionsPromise
  }

  return options
}

if (!globalThis.__fetch) {
  globalThis.__fetch = fetch
}

export async function request(input, init) {
  const fetch = globalThis.__fetch
  const u = new URL(
    typeof input === "string" ? input : input.url,
    location?.origin
  )
  const {
    proxyIncludes,
    mode,
    cfcBase,
    anthropicBaseUrl,
    apiBaseIncludes,
    discardIncludes,
    modelAlias,
  } = await getOptions()

  // Pass real oauth token exchanges (code not prefixed cfc-) through to Anthropic
  try {
    if (
      u.href.startsWith("https://console.anthropic.com/v1/oauth/token") &&
      typeof init?.body == "string"
    ) {
      const p = new URLSearchParams(init.body)
      const code = p.get("code")
      if (code && !code.startsWith("cfc-")) {
        return fetch(input, init)
      }
    }
  } catch (e) {
    console.log(e)
  }

  // API base: forward to configured local backend
  if (mode != "claude" && isMatch(u, apiBaseIncludes)) {
    const apiBase =
      globalThis.localStorage?.getItem("apiBaseUrl") ||
      anthropicBaseUrl ||
      u.origin
    const url = apiBase + u.pathname + u.search
    try {
      if (init?.method == "POST" && typeof init?.body == "string") {
        const body = JSON.parse(init.body)
        const { model } = body
        if (model && modelAlias[model]) {
          body.model = modelAlias[model]
          init.body = JSON.stringify(body)
        }
      }
    } catch (e) {}
    console.log("[hijack] API ->", url)
    return fetch(url, init)
  }

  // Discard: telemetry / analytics → 204
  if (isMatch(u, discardIncludes)) {
    return new Response(null, { status: 204 })
  }

  // Proxy: auth + bootstrap + options → local CFC proxy
  if (isMatch(u, proxyIncludes)) {
    const url = cfcBase + u.href
    return fetch(url, init)
  }

  return fetch(input, init)
}

request.toString = () => globalThis.__fetch.toString()
globalThis.fetch = request

// XHR intercept — same routing logic for legacy XMLHttpRequest callers
if (globalThis.XMLHttpRequest) {
  if (!globalThis.__xhrOpen) {
    globalThis.__xhrOpen = XMLHttpRequest?.prototype?.open
  }
  XMLHttpRequest.prototype.open = function (method, url, ...args) {
    const originalOpen = globalThis.__xhrOpen
    const { cfcBase, proxyIncludes, discardIncludes } = globalThis.__cfc_options
    let finalUrl = url
    if (isMatch(url, proxyIncludes)) {
      finalUrl = cfcBase + url
    }
    if (isMatch(url, discardIncludes)) {
      finalUrl = (cfcBase + url).replace("/https://", "/")
      method = "GET"
    }
    originalOpen.call(this, method, finalUrl, ...args)
  }
}

// tabs.create: redirect claude.ai oauth to local proxy
if (!globalThis.__createTab) {
  globalThis.__createTab = chrome?.tabs?.create
}
if (chrome?.tabs?.create) {
  chrome.tabs.create = async function (...args) {
    const url = args[0]?.url
    if (url && url.startsWith("https://claude.ai/oauth/authorize")) {
      const { cfcBase, mode } = await getOptions()
      const m = chrome?.runtime?.getManifest
        ? chrome.runtime.getManifest()
        : { version: "0" }
      if (mode !== "claude") {
        args[0].url =
          url
            .replace("https://claude.ai/", cfcBase)
            .replace("fcoeoabgfenejglbffodgkkbkcdhcgfn", chrome?.runtime?.id || "unknown") +
          `&v=${m.version}`
      }
    }
    if (url && url == "https://claude.ai/upgrade?max=c") {
      const { cfcBase, mode } = await getOptions()
      if (mode !== "claude") {
        args[0].url = cfcBase + "?from=" + encodeURIComponent(url)
      }
    }
    return __createTab.apply(chrome.tabs, args)
  }
}

// External message handler — matches cocodem's message protocol exactly
if (chrome?.runtime?.onMessageExternal?.addListener) {
  chrome.runtime.onMessageExternal.addListener(
    async (msg, sender, sendResponse) => {
      try {
        if (sender) {
          sender.origin = "https://claude.ai"
        }
        switch (msg?.type) {
          case "ping":
            setTimeout(() => { 
              try { sendResponse({ success: !0 }) } catch(e) {} 
            }, 1000)
            return true
          case "_claude_account_mode":
            await clearApiKeyLogin()
            break
          case "_api_key_mode":
            await getOptions(true)
            break
          case "_update_options":
            await getOptions(true)
            break
          case "_set_storage_local":
            if (chrome?.storage?.local?.set) await chrome.storage.local.set(msg.data)
            try { sendResponse() } catch(e) {}
            break
          case "_get_storage_local":
            if (chrome?.storage?.local?.get) {
              const data = await chrome.storage.local.get(msg.keys || null)
              try { sendResponse(data) } catch(e) {}
            }
            break
          case "_open_options":
            if (chrome?.runtime?.openOptionsPage) await chrome.runtime.openOptionsPage()
            break
          case "_create_tab":
            if (chrome?.tabs?.create) await chrome.tabs.create({ url: msg.url })
            break
          case "oauth_redirect":
            const { redirect_uri } = msg
            if (redirect_uri && redirect_uri.includes("sidepanel.html")) {
              try {
                const u = new URL(redirect_uri)
                const code = u.searchParams.get("code")
                if (code) {
                  await chrome.storage.local.set({
                    sidepanelToken: "cfc-" + code,
                    sidepanelTokenExpiry: Date.now() + 31536000000,
                  })
                }
              } catch(e) {}
              try { sendResponse({ success: true }) } catch(e) {}
            } else {
              try { sendResponse({ success: false }) } catch(e) {}
            }
            break
        }
      } catch (e) {
        console.log("[hijack] Message handler error:", e.message)
      }
    }
  )
}

// Standard message handler for same-extension messages
if (chrome?.runtime?.onMessage?.addListener) {
  chrome.runtime.onMessage.addListener(
    (msg, sender, sendResponse) => {
      try {
        switch (msg?.type) {
          case "_set_storage_local":
            if (chrome?.storage?.local?.set) {
              chrome.storage.local.set(msg.data).then(() => {
                try { sendResponse() } catch(e) {}
              }).catch(() => {
                try { sendResponse() } catch(e) {}
              })
              return true
            }
            break
          case "_get_storage_local":
            if (chrome?.storage?.local?.get) {
              chrome.storage.local.get(msg.keys || null).then((data) => {
                try { sendResponse(data) } catch(e) {}
              }).catch(() => {
                try { sendResponse({}) } catch(e) {}
              })
              return true
            }
            break
          case "_open_options":
            if (chrome?.runtime?.openOptionsPage) {
              chrome.runtime.openOptionsPage()
            }
            break
          case "_create_tab":
            if (chrome?.tabs?.create) {
              chrome.tabs.create({ url: msg.url })
            }
            break
          case "oauth_redirect":
            const { redirect_uri } = msg
            if (redirect_uri && redirect_uri.includes("sidepanel.html")) {
              try {
                const u = new URL(redirect_uri)
                const code = u.searchParams.get("code")
                if (code) {
                  chrome.storage.local.set({
                    sidepanelToken: "cfc-" + code,
                    sidepanelTokenExpiry: Date.now() + 31536000000,
                  })
                }
              } catch(e) {}
              try { sendResponse({ success: true }) } catch(e) {}
            } else {
              try { sendResponse({ success: false }) } catch(e) {}
            }
            break
        }
      } catch (e) {
        console.log("[hijack] Standard message handler error:", e.message)
      }
    }
  )
}

// ── sidePanel.open override: Arc / non-Chrome ONLY ──────────────────────────
// DO NOT override on real Google Chrome — the native API works fine there.
// Overriding it on Chrome causes sidePanel to redirect to arc.html instead
// of opening the side panel, which is the root cause of the blank side panel.
if (!globalThis.__openSidePanel) {
  globalThis.__openSidePanel = chrome?.sidePanel?.open
}
const isChrome = navigator?.userAgentData?.brands?.some(
  (b) => b.brand == "Google Chrome"
)
if (!isChrome && chrome?.sidePanel) {
  chrome.sidePanel.open = async (...args) => {
    const open = globalThis.__openSidePanel
    try {
      const result = await open.apply(chrome.sidePanel, args)
      if (chrome.runtime.getContexts) {
        const contexts = await chrome.runtime.getContexts({
          contextTypes: ["SIDE_PANEL"],
        })
        if (contexts.length === 0) {
          chrome.tabs.create({ url: "/arc.html" })
        }
      }
      return result
    } catch (e) {
      chrome.tabs.create({ url: "/arc.html" })
      return null
    }
  }
}

// ── Window context: page-specific logic ─────────────────────────────────────
if (globalThis.window) {
  function render() {
    const { ui } = globalThis.__cfc_options
    const pageUi = ui[location.pathname]
    if (pageUi) {
      Object.values(pageUi).forEach((item) => {
        const el = document.querySelector(item.selector)
        if (el) el.innerHTML = item.html
      })
    }
  }
  window.addEventListener("DOMContentLoaded", render)
  window.addEventListener("popstate", render)

  // ── sidepanel.html: OAuth check + inject REAL tabId — no fake 999999 pre-set ──
  // Pre-setting a fake ID causes React to mount with a non-existent tabId,
  // connecting scripting to tab 999999 which doesn't exist → blank side panel.
  if (location.pathname == "/sidepanel.html" && location.search == "") {
    // Check for valid sidepanel token — if missing, start OAuth flow
    chrome.storage.local.get({ sidepanelToken: "", sidepanelTokenExpiry: 0 }).then(({ sidepanelToken, sidepanelTokenExpiry }) => {
      const now = Date.now()
      if (!sidepanelToken || !sidepanelTokenExpiry || sidepanelTokenExpiry < now) {
        // No valid token — redirect to OAuth authorize endpoint
        const redirectUri = encodeURIComponent(
          "chrome-extension://" + (chrome?.runtime?.id || "unknown") + "/sidepanel.html"
        )
        const authorizeUrl = cfcBase + "oauth/authorize?redirect_uri=" + redirectUri +
          "&response_type=code&client_id=sidepanel&state=" + Date.now()
        chrome.tabs.create({ url: authorizeUrl })
        return // Stop here — wait for OAuth completion
      }
      // Token exists and valid — inject tabId and proceed
      chrome.tabs.query({ active: !0, currentWindow: !0 }).then(([tab]) => {
        if (tab) {
          const u = new URL(location.href)
          u.searchParams.set("tabId", tab.id)
          history.replaceState(null, "", u.href)
        }
      }).catch(() => {})
    }).catch(() => {})
  }

  // Handle OAuth redirect back to sidepanel
  if (location.pathname == "/sidepanel.html" && location.search.includes("code=")) {
    const params = new URLSearchParams(location.search)
    const code = params.get("code")
    if (code) {
      chrome.storage.local.set({
        sidepanelToken: "cfc-" + code,
        sidepanelTokenExpiry: Date.now() + 31536000000,
      })
      const u = new URL(location.href)
      u.search = "" // clear code from URL
      history.replaceState(null, "", u.href)
    }
  }

  // ── arc.html: Arc browser sidepanel fallback ──
  if (location.pathname == "/arc.html") {
    const _fetch = globalThis.__fetch
    _fetch(cfcBase + "api/arc-split-view")
      .then((res) => res.json())
      .then((data) => {
        const el = document.querySelector(".animate-spin")
        if (el) el.outerHTML = data.html
      }).catch(() => {})

    _fetch("/options.html")
      .then((res) => res.text())
      .then((html) => {
        const matches = html.match(/[^"\s]+?\.css/g) || []
        for (const url of matches) {
          const link = document.createElement("link")
          link.rel = "stylesheet"
          link.href = url
          document.head.appendChild(link)
        }
      }).catch(() => {})

    window.addEventListener("resize", async () => {
      try {
        const tabs = await chrome.tabs.query({ currentWindow: true })
        const tab = await new Promise((resolve, reject) => {
          let found = false
          tabs.forEach(async (t) => {
            if (t.url?.startsWith(location.origin)) return
            try {
              const [value] = await chrome.scripting.executeScript({
                target: { tabId: t.id },
                func: () => document.visibilityState,
              })
              if (value?.result == "visible" && !found) {
                found = true
                resolve(t)
              }
            } catch(e) {}
          })
          setTimeout(() => { if (!found) reject() }, 2000)
        })
        if (tab) {
          location.href = "/sidepanel.html?tabId=" + tab.id
          chrome.tabs.update(tab.id, { active: true })
        }
      } catch(e) {}
    })

    chrome.system?.display?.getInfo().then(([info]) => {
      if (info) location.hash = "id=" + info.id
    }).catch(() => {})
  }

  // ── options.html: inject Backend Settings button ──
  // Links to /options.html#backendsettings (chrome-extension:// context, not proxy)
  if (location.pathname == "/options.html") {
    const _observer = new MutationObserver(() => {
      if (document.getElementById("__cfc_backend_btn")) {
        _observer.disconnect()
        return
      }
      const allItems = document.querySelectorAll("a, button")
      let logoutEl = null
      allItems.forEach(el => {
        if (el.textContent.trim().toLowerCase().includes("log out")) logoutEl = el
      })
      if (!logoutEl) return

      const link = document.createElement("a")
      link.id = "__cfc_backend_btn"
      link.href = "/options.html#backendsettings"
      link.className = logoutEl.className
      link.innerHTML = "\u2699\ufe0f Backend Settings"
      link.style.color = "#e07a5f"
      link.style.fontWeight = "600"
      logoutEl.parentElement.insertBefore(link, logoutEl)

      const handleHash = () => {
        if (location.hash === "#backendsettings") {
          const main = document.querySelector("main") || document.body
          main.innerHTML = `<div id="__cfc_settings_container"></div>`
          // Load settings UI as external script (not inline — MV3 CSP compliant)
          const script = document.createElement("script")
          script.src = "/assets/backend_settings_ui.js"
          document.body.appendChild(script)
        }
      }
      window.addEventListener("hashchange", handleHash)
      handleHash()
      _observer.disconnect()
    })
    _observer.observe(document.body, { childList: true, subtree: true })
  }
}

// ── JSX remix helpers ────────────────────────────────────────────────────────

function matchJsx(node, selector) {
  if (!node || !selector) return false
  if (selector.type && node.type != selector.type) return false
  if (selector.key  && node.key  != selector.key)  return false
  let p = node.props || {}
  let m = selector.props || {}
  for (let k of Object.keys(m)) {
    if (k == "children") continue
    if (m[k] != p?.[k]) return false
  }
  if (m.children === undefined)        return true
  if (m.children === p?.children)      return true
  if (m.children && !p?.children)      return false
  if (Array.isArray(m.children)) {
    if (!Array.isArray(p?.children)) return false
    return m.children.every((c, i) => c == null || matchJsx(p?.children[i], c))
  }
  return matchJsx(p?.children, m.children)
}

function remixJsx(node, renderNode) {
  const { uiNodes } = globalThis.__cfc_options
  if (!uiNodes || uiNodes.length === 0) {
    return node
  }
  let { props = {}, type, key } = node
  for (const item of uiNodes) {
    if (!matchJsx({ type, props, key }, item.selector)) continue
    let newProps = { ...props }
    if (item.prepend) {
      let children = Array.isArray(newProps.children)
        ? newProps.children
        : (newProps.children != null ? [newProps.children] : [])
      newProps.children = [renderNode(item.prepend), ...children]
    }
    if (item.append) {
      let children = Array.isArray(newProps.children)
        ? newProps.children
        : (newProps.children != null ? [newProps.children] : [])
      newProps.children = [...children, renderNode(item.append)]
    }
    if (item.replace) {
      const rep = renderNode(item.replace)
      return rep ? rep : { type, props: newProps, key }
    }
    props = newProps
  }
  return { type, props, key }
}

export function setJsx(n) {
  if (!n || !n.jsx) return;
  const originalJsx = n.jsx;
  const originalJsxs = n.jsxs;
  const renderNode = (node) => {
    if (!node || !node.type) return node;
    if (node.$$typeof === Symbol.for("react.element")) {
        return node;
    }
    const { type, props, key } = node;
    const children = props.children ? (Array.isArray(props.children) ? props.children.map(renderNode) : renderNode(props.children)) : [];
    return originalJsx(type, { ...props, children }, key);
  };

  n.jsx = function (type, props, key) {
    const node = remixJsx({ type, props, key }, renderNode);
    return originalJsx(node.type, node.props, node.key);
  };

  n.jsxs = function (type, props, key) {
    const node = remixJsx({ type, props, key }, renderNode);
    return originalJsxs(node.type, node.props, node.key);
  };
}

// ── Auth bootstrap: set local tokens if not already set ─────────────────────
// FIX: Use iss="cfc" - clearApiKeyLogin deletes tokens with iss=="auth"
if (chrome?.storage?.local?.get) {
  chrome.storage.local.get({ accessToken: "", accountUuid: "" }).then(({ accessToken, accountUuid }) => {
    if (!accessToken || !accountUuid) {
      const header  = btoa(JSON.stringify({ alg: "none", typ: "JWT" }))
      const payload = btoa(JSON.stringify({
        iss: "cfc",
        sub: "local-user",
        exp: 9999999999,
        iat: Math.floor(Date.now() / 1000),
      }))
      chrome.storage.local.set({
        accessToken:  header + "." + payload + ".local",
        refreshToken: "local-refresh",
        tokenExpiry:  Date.now() + 31536000000,
        accountUuid:  "local-user-uuid",
      })
      console.log("[hijack] Auth tokens and accountUuid set")
    }
  })
}

// Sync apiBaseUrl in localStorage when hijackSettings changes
if (chrome?.storage?.onChanged?.addListener) {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes.hijackSettings?.newValue?.backendUrl) {
      try {
        if (globalThis.localStorage) {
          globalThis.localStorage.setItem("apiBaseUrl", changes.hijackSettings.newValue.backendUrl)
        }
      } catch(e) {}
    }
  })
}

console.log("[hijack] Loaded in:", globalThis.window ? (location?.pathname || "unknown") : "service_worker")
