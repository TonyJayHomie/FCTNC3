import os

import re

import json

import shutil

import zipfile

from datetime import datetime



# =================================================================

# CLAUDE EXTENSION: NUCLEAR CLEANROOM SANITIZER (v3.3 - ULTIMATE)

# TARGET: ZERO-LOGIN, NO TELEMETRY, CSP COMPLIANT, LOCAL REDIRECT

# =================================================================



# --- CONFIGURATION ---

LOCAL_GATEWAY_URL = "http://127.0.0.1:1234/v1"

MANUAL_EXT_PATH = ""



MALICIOUS_DOMAINS = [

    "openclaude.111724.xyz", "111724.xyz", "cfc.aroic.workers.dev",

    "openclaude.com", "openclaude.net", "aroic.workers.dev"

]



ANALYTICS_DOMAINS = [

    "segment.io", "segment.com", "statsigapi.net", "statsigcdn.com",

    "datadoghq.com", "sentry.io", "honeycomb.io", "featureassets.org",

    "featuregates.org", "amplitude.com", "mixpanel.com"

]



def find_extension():

    if MANUAL_EXT_PATH and os.path.exists(MANUAL_EXT_PATH):

        return MANUAL_EXT_PATH

    ext_id = "fcoeoabgfenejglbffodgkkbkcdhcgfn"

    app_data = os.environ.get('LOCALAPPDATA', '')

    home = os.path.expanduser("~")

    search_roots = [

        os.path.join(app_data, "Google", "Chrome", "User Data"),

        os.path.join(app_data, "Microsoft", "Edge", "User Data"),

        os.path.join(home, "Library/Application Support/Google/Chrome"),

        os.path.join(home, ".config/google-chrome"),

    ]

    for root in search_roots:

        if not os.path.exists(root): continue

        for profile in ["Default", "Profile 1", "Profile 2", "Profile 3"]:

            p = os.path.join(root, profile, "Extensions", ext_id)

            if os.path.exists(p):

                versions = [v for v in os.listdir(p) if os.path.isdir(os.path.join(p, v))]

                if versions:

                    return os.path.join(p, sorted(versions)[-1])

    return None



def sanitize():

    print("=== CLAUDE EXTENSION: NUCLEAR CLEANROOM REWRITE v3.3 ===")

    src_path = find_extension()

    if not src_path:

        print("[-] ERROR: Extension source folder not found.")

        return



    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    out_dir = os.path.join(os.path.expanduser("~"), "Desktop", f"Claude_Cleanroom_{timestamp}")

    shutil.copytree(src_path, out_dir)



    # 1. FIX CSP: Create a generic script file for all inline logic

    injected_js_name = "cleanroom-injected.js"

    injected_js_content = """

    // Cleanroom Theme & Logic Injection

    (function () {

        const isDark = window.matchMedia("(prefers-color-scheme: dark)").matches;

        document.documentElement.setAttribute("data-mode", isDark ? "dark" : "light");

        window.matchMedia("(prefers-color-scheme: dark)").addEventListener("change", (e) => {

            document.documentElement.setAttribute("data-mode", e.matches ? "dark" : "light");

        });

        console.log("Nuclear Cleanroom: Theme Logic Active");

    })();

    """

    with open(os.path.join(out_dir, injected_js_name), 'w', encoding='utf-8') as f:

        f.write(injected_js_content)



    # 2. Manifest Hardening

    manifest_path = os.path.join(out_dir, "manifest.json")

    if os.path.exists(manifest_path):

        with open(manifest_path, 'r', encoding='utf-8') as f:

            m = json.load(f)

        m.pop("update_url", None)

        m["name"] = "Claude (Cleanroom Rewrite)"

        m["description"] = "Sanitized Local Gateway Version"

       

        # MV3 CSP & Permissions

        m["host_permissions"] = m.get("host_permissions", [])

        if "<all_urls>" not in m["host_permissions"]: m["host_permissions"].append("<all_urls>")

        m["permissions"] = [p for p in m.get("permissions", []) if p != "<all_urls>"]

       

        # Ensure we can load our injected scripts

        if "content_security_policy" in m:

            m["content_security_policy"]["extension_pages"] = "script-src 'self'; object-src 'self'"

           

        with open(manifest_path, 'w', encoding='utf-8') as f:

            json.dump(m, f, indent=2)



    # 3. HTML Scrubbing (CSP Fix)

    for html_file in ["sidepanel.html", "pairing.html", "options.html", "newtab.html", "arc.html"]:

        p = os.path.join(out_dir, html_file)

        if os.path.exists(p):

            with open(p, 'r', encoding='utf-8') as f:

                html = f.read()

            # Remove ANY inline script blocks and replace with the safe file reference

            html = re.sub(r'<script>(.*?)<\/script>', f'<script src="/{injected_js_name}"></script>', html, flags=re.DOTALL)

            with open(p, 'w', encoding='utf-8') as f:

                f.write(html)



    # 4. JavaScript Logic Bomb (Auth & Telemetry Removal)

    file_count = 0

    for root, _, files in os.walk(out_dir):

        for f in files:

            if f.endswith(".js"):

                f_path = os.path.join(root, f)

                try:

                    with open(f_path, 'r', encoding='utf-8', errors='ignore') as file:

                        c = file.read()

                    orig = c



                    # A. Kill Telemetry Init (Datadog/Sentry)

                    c = re.sub(r'CL\(\);', '/* CL_KILLED */', c) # Specific to useStorageState-hbwNMVUA.js

                    c = re.sub(r'xL\.init\(.*?\);', '/* Telemetry_Killed */', c)

                    for d in ANALYTICS_DOMAINS:

                        c = c.replace(d, "127.0.0.1")



                    # B. Auth Bypass (Profile Query Redirection)

                    # We look for the userProfile query logic and force it to resolve locally

                    c = c.replace('queryFn:async()=>g.fetch("/api/oauth/profile")', f'queryFn:async()=>({{account:{{uuid:"local-bypass",email:"local@gateway"}},organization:{{uuid:"local-bypass",organization_type:"personal"}},isAuthenticated:true}})')

                   

                    # C. Hard-Redirect URLs

                    c = c.replace("https://api.anthropic.com", LOCAL_GATEWAY_URL)

                    c = c.replace("https://claude.ai/api", LOCAL_GATEWAY_URL)

                    for d in MALICIOUS_DOMAINS:

                        c = c.replace(f"https://{d}", LOCAL_GATEWAY_URL).replace(d, "127.0.0.1")



                    # D. Boolean Force-Login Neutralizer

                    c = c.replace("isAuthenticated:!1", "isAuthenticated:!0")

                    c = c.replace("isAuthenticated:false", "isAuthenticated:true")

                    c = c.replace("is_authenticated:!1", "is_authenticated:!0")

                    c = c.replace("is_authenticated:false", "is_authenticated:true")

                   

                    # E. Storage Mocking (Nuclear Version)

                    # Force chrome.storage to always return valid objects

                    c = c.replace('await chrome.storage.local.get(e)', 'Promise.resolve({"accessToken":"LOCAL_BYPASS","isValid":true})')



                    # F. RemixJsx / request.js Sanitization

                    c = re.sub(r'const cfcBase\s*=\s*".*?"', f'const cfcBase = "{LOCAL_GATEWAY_URL}"', c)

                    c = re.sub(r'function remixJsx\(.*?\)\{.*?\}', 'function remixJsx(n,r){return n}', c, flags=re.DOTALL)



                    if c != orig:

                        with open(f_path, 'w', encoding='utf-8') as file:

                            file.write(c)

                        file_count += 1

                except: pass



    # 5. Pack ZIP

    zip_path = out_dir + ".zip"

    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as z:

        for r, _, fs in os.walk(out_dir):

            for file in fs:

                fp = os.path.join(r, file)

                z.write(fp, os.path.relpath(fp, out_dir))



    print(f"\n[SUCCESS] Patched {file_count} logic files.")

    print(f"[+] Datadog error eliminated.")

    print(f"[+] Login screen bypassed via React state injection.")

    print(f"[+] Workspace: {out_dir}")

    print(f"[+] Deployment ZIP created on Desktop.")



if __name__ == "__main__":

    sanitize()